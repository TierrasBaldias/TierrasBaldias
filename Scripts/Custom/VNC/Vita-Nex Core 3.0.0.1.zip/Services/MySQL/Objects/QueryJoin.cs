﻿#region Header
//   Vorspire    _,-'/-'/  QueryJoin.cs
//   .      __,-; ,'( '/
//    \.    `-.__`-._`:_,-._       _ , . ``
//     `:-._,------' ` _,`--` -: `_ , ` ,' :
//        `---..__,,--'  (C) 2016  ` -'. -'
//        #  Vita-Nex [http://core.vita-nex.com]  #
//  {o)xxx|===============-   #   -===============|xxx(o}
//        #        The MIT License (MIT)          #
#endregion

namespace VitaNex.MySQL
{
	public enum MySQLQueryJoin
	{
		AND = 0x00,
		OR = 0x01
	}
}
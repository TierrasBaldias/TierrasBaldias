﻿#region Header
//   Vorspire    _,-'/-'/  ITrashTokenProperties.cs
//   .      __,-; ,'( '/
//    \.    `-.__`-._`:_,-._       _ , . ``
//     `:-._,------' ` _,`--` -: `_ , ` ,' :
//        `---..__,,--'  (C) 2016  ` -'. -'
//        #  Vita-Nex [http://core.vita-nex.com]  #
//  {o)xxx|===============-   #   -===============|xxx(o}
//        #        The MIT License (MIT)          #
#endregion

#region References
using Server;
#endregion

namespace VitaNex.Modules.TrashCollection
{
	public interface ITrashTokenProperties
	{
		void GetProperties(ObjectPropertyList list);
		void InvalidateProperties();
	}
}